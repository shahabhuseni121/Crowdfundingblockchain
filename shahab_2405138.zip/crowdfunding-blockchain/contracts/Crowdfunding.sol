// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract Crowdfunding {
    struct Campaign {
        address payable creator;
        string title;
        string description;
        uint256 goal;
        uint256 deadline;
        uint256 totalFunds;
        bool isCompleted;
        mapping(address => uint256) contributions;
    }

    uint256 public campaignCount;
    mapping(uint256 => Campaign) public campaigns;

    event CampaignCreated(
        uint256 id,
        address creator,
        string title,
        uint256 goal,
        uint256 deadline
    );

    event FundContributed(
        uint256 campaignId,
        address contributor,
        uint256 amount
    );

    event FundsWithdrawn(
        uint256 campaignId,
        address creator,
        uint256 amount
    );

    event CampaignCompleted(
        uint256 campaignId,
        bool success
    );

    function createCampaign(
        string memory _title,
        string memory _description,
        uint256 _goal,
        uint256 _durationInDays
    ) external {
        require(bytes(_title).length > 0, "Title is required");
        require(bytes(_description).length > 0, "Description is required");
        require(_goal > 0, "Goal must be greater than 0");
        require(_durationInDays > 0, "Duration must be greater than 0");

        uint256 deadline = block.timestamp + (_durationInDays * 1 days);
        campaignCount++;

        Campaign storage newCampaign = campaigns[campaignCount];
        newCampaign.creator = payable(msg.sender);
        newCampaign.title = _title;
        newCampaign.description = _description;
        newCampaign.goal = _goal;
        newCampaign.deadline = deadline;
        newCampaign.totalFunds = 0;
        newCampaign.isCompleted = false;

        emit CampaignCreated(
            campaignCount,
            msg.sender,
            _title,
            _goal,
            deadline
        );
    }

    function contribute(uint256 _campaignId) external payable {
        require(_campaignId > 0 && _campaignId <= campaignCount, "Invalid campaign ID");
        Campaign storage campaign = campaigns[_campaignId];
        require(!campaign.isCompleted, "Campaign is already completed");
        require(block.timestamp < campaign.deadline, "Campaign deadline has passed");
        require(msg.value > 0, "Contribution amount must be greater than 0");

        campaign.contributions[msg.sender] += msg.value;
        campaign.totalFunds += msg.value;

        emit FundContributed(_campaignId, msg.sender, msg.value);

        if (campaign.totalFunds >= campaign.goal) {
            _completeCampaign(_campaignId, true);
        }
    }

    function withdrawFunds(uint256 _campaignId) external {
        require(_campaignId > 0 && _campaignId <= campaignCount, "Invalid campaign ID");
        Campaign storage campaign = campaigns[_campaignId];
        require(msg.sender == campaign.creator, "Only creator can withdraw");
        require(!campaign.isCompleted, "Campaign is already completed");
        require(block.timestamp >= campaign.deadline, "Campaign deadline not reached");
        require(campaign.totalFunds >= campaign.goal, "Goal not reached");

        uint256 amount = campaign.totalFunds;
        campaign.totalFunds = 0;
        campaign.isCompleted = true;
        campaign.creator.transfer(amount);

        emit FundsWithdrawn(_campaignId, msg.sender, amount);
        emit CampaignCompleted(_campaignId, true);
    }

    function refund(uint256 _campaignId) external {
        require(_campaignId > 0 && _campaignId <= campaignCount, "Invalid campaign ID");
        Campaign storage campaign = campaigns[_campaignId];
        require(!campaign.isCompleted, "Campaign is already completed");
        require(block.timestamp >= campaign.deadline, "Campaign deadline not reached");
        require(campaign.totalFunds < campaign.goal, "Goal was reached");
        require(campaign.contributions[msg.sender] > 0, "No contribution to refund");

        uint256 amount = campaign.contributions[msg.sender];
        campaign.contributions[msg.sender] = 0;
        payable(msg.sender).transfer(amount);

        emit CampaignCompleted(_campaignId, false);
    }

    function _completeCampaign(uint256 _campaignId, bool success) internal {
        Campaign storage campaign = campaigns[_campaignId];
        campaign.isCompleted = true;
        emit CampaignCompleted(_campaignId, success);
    }

    function getContributionAmount(uint256 _campaignId, address contributor) public view returns (uint256) {
        return campaigns[_campaignId].contributions[contributor];
    }

    function getCampaignDetails(uint256 _campaignId) public view returns (
        address creator,
        string memory title,
        string memory description,
        uint256 goal,
        uint256 deadline,
        uint256 totalFunds,
        bool isCompleted
    ) {
        Campaign storage campaign = campaigns[_campaignId];
        return (
            campaign.creator,
            campaign.title,
            campaign.description,
            campaign.goal,
            campaign.deadline,
            campaign.totalFunds,
            campaign.isCompleted
        );
    }
}