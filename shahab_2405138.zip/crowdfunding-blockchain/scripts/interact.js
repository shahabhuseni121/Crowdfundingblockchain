const Crowdfunding = artifacts.require("Crowdfunding");

module.exports = async function (callback) {
  try {
    const crowdfunding = await Crowdfunding.deployed();
    console.log("Crowdfunding contract instance:", crowdfunding.address);

    // Example: Create a campaign
    console.log("Creating a new campaign...");
    await crowdfunding.createCampaign(
      "Sample Campaign",
      "This is a sample crowdfunding campaign",
      web3.utils.toWei("5", "ether"),
      30
    );
    console.log("Campaign created!");

    // Get campaign details
    const campaign = await crowdfunding.getCampaignDetails(1);
    console.log("Campaign details:", campaign);

  } catch (error) {
    console.error("Error:", error);
  }

  callback();
};