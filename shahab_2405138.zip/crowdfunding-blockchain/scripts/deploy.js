const Crowdfunding = artifacts.require("Crowdfunding");

module.exports = async function (deployer, network, accounts) {
  await deployer.deploy(Crowdfunding);
  const crowdfunding = await Crowdfunding.deployed();

  console.log("Crowdfunding contract deployed at:", crowdfunding.address);
  console.log("Deployer account:", accounts[0]);
};