const Crowdfunding = artifacts.require("Crowdfunding");

contract("Crowdfunding", (accounts) => {
  let crowdfunding;
  const [creator, contributor1, contributor2] = accounts;

  before(async () => {
    crowdfunding = await Crowdfunding.new();
  });

  it("should create a new campaign", async () => {
    const title = "Test Campaign";
    const description = "This is a test campaign";
    const goal = web3.utils.toWei("10", "ether");
    const durationInDays = 7;

    const result = await crowdfunding.createCampaign(
      title,
      description,
      goal,
      durationInDays,
      { from: creator }
    );

    const campaign = await crowdfunding.campaigns(1);
    assert.equal(campaign.creator, creator);
    assert.equal(campaign.title, title);
    assert.equal(campaign.goal, goal);
    assert.isFalse(campaign.isCompleted);

    const event = result.logs[0].args;
    assert.equal(event.id, 1);
    assert.equal(event.creator, creator);
    assert.equal(event.title, title);
    assert.equal(event.goal, goal);
  });

  it("should accept contributions", async () => {
    const contributionAmount = web3.utils.toWei("1", "ether");
    await crowdfunding.contribute(1, {
      from: contributor1,
      value: contributionAmount,
    });

    const campaign = await crowdfunding.campaigns(1);
    assert.equal(campaign.totalFunds, contributionAmount);

    const contribution = await crowdfunding.getContributionAmount(
      1,
      contributor1
    );
    assert.equal(contribution, contributionAmount);
  });

  it("should complete campaign when goal is reached", async () => {
    // Complete the goal with a second contribution
    const contributionAmount = web3.utils.toWei("9", "ether");
    const result = await crowdfunding.contribute(1, {
      from: contributor2,
      value: contributionAmount,
    });

    const campaign = await crowdfunding.campaigns(1);
    assert.equal(
      campaign.totalFunds,
      web3.utils.toWei("10", "ether")
    );
    assert.isTrue(campaign.isCompleted);

    // Check for CampaignCompleted event
    const event = result.logs.find(log => log.event === "CampaignCompleted");
    assert.exists(event);
    assert.isTrue(event.args.success);
  });
});