step 1  setup ganache 
step 2 install node.js
step 3 install meta mask extention (for your eth wallet)
step 3 install latest truffule and ganache globally on your terminal (npm install -g truffle ganache)
now  here are the commands

ganache
// open new terminal 
 cd C:\Users\anand\OneDrive\ドキュメント\crowdfunding-blockchain
 cd frontend
 npx http-server -p 3000 --cors
