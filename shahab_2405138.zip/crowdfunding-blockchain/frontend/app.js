document.addEventListener('DOMContentLoaded', () => {
    let web3;
    let contract;
    let accounts = [];
    let currentCampaignId = null;

    // Contract ABI (simplified for frontend)
    const contractABI = [
        {
            "inputs": [
                {"internalType": "string", "name": "_title", "type": "string"},
                {"internalType": "string", "name": "_description", "type": "string"},
                {"internalType": "uint256", "name": "_goal", "type": "uint256"},
                {"internalType": "uint256", "name": "_durationInDays", "type": "uint256"}
            ],
            "name": "createCampaign",
            "outputs": [],
            "stateMutability": "nonpayable",
            "type": "function"
        },
        {
            "inputs": [{"internalType": "uint256", "name": "_campaignId", "type": "uint256"}],
            "name": "contribute",
            "outputs": [],
            "stateMutability": "payable",
            "type": "function"
        },
        {
            "inputs": [],
            "name": "campaignCount",
            "outputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [{"internalType": "uint256", "name": "", "type": "uint256"}],
            "name": "campaigns",
            "outputs": [
                {"internalType": "address payable", "name": "creator", "type": "address"},
                {"internalType": "string", "name": "title", "type": "string"},
                {"internalType": "string", "name": "description", "type": "string"},
                {"internalType": "uint256", "name": "goal", "type": "uint256"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                {"internalType": "uint256", "name": "totalFunds", "type": "uint256"},
                {"internalType": "bool", "name": "isCompleted", "type": "bool"}
            ],
            "stateMutability": "view",
            "type": "function"
        },
        {
            "inputs": [{"internalType": "uint256", "name": "_campaignId", "type": "uint256"}],
            "name": "getCampaignDetails",
            "outputs": [
                {"internalType": "address", "name": "creator", "type": "address"},
                {"internalType": "string", "name": "title", "type": "string"},
                {"internalType": "string", "name": "description", "type": "string"},
                {"internalType": "uint256", "name": "goal", "type": "uint256"},
                {"internalType": "uint256", "name": "deadline", "type": "uint256"},
                {"internalType": "uint256", "name": "totalFunds", "type": "uint256"},
                {"internalType": "bool", "name": "isCompleted", "type": "bool"}
            ],
            "stateMutability": "view",
            "type": "function"
        }
    ];

    // Contract address (update this after deployment)
    const contractAddress = "0x123..."; // Replace with your deployed contract address

    // Connect to MetaMask
    document.getElementById('connect-wallet').addEventListener('click', connectWallet);

    // Campaign form submission
    document.getElementById('campaign-form').addEventListener('submit', createCampaign);

    // Modal close button
    document.querySelector('.close').addEventListener('click', () => {
        document.getElementById('modal').style.display = 'none';
    });

    // Contribute button in modal
    document.getElementById('contribute-btn').addEventListener('click', contributeToCampaign);

    async function connectWallet() {
        if (window.ethereum) {
            try {
                web3 = new Web3(window.ethereum);
                await window.ethereum.request({ method: 'eth_requestAccounts' });
                accounts = await web3.eth.getAccounts();
                
                // Initialize contract
                contract = new web3.eth.Contract(contractABI, contractAddress);
                
                // Update UI
                document.getElementById('wallet-address').textContent = 
                    `${accounts[0].substring(0, 6)}...${accounts[0].substring(38)}`;
                document.getElementById('connect-wallet').textContent = 'Connected';
                document.getElementById('connect-wallet').disabled = true;
                
                // Load campaigns
                loadCampaigns();
            } catch (error) {
                console.error("Error connecting to MetaMask:", error);
                alert("Failed to connect to MetaMask. Please try again.");
            }
        } else {
            alert("MetaMask is not installed. Please install it to use this application.");
        }
    }

    async function createCampaign(e) {
        e.preventDefault();
        
        if (!contract) {
            alert("Please connect your wallet first.");
            return;
        }
        
        const title = document.getElementById('title').value;
        const description = document.getElementById('description').value;
        const goal = document.getElementById('goal').value;
        const duration = document.getElementById('duration').value;
        
        try {
            const goalInWei = web3.utils.toWei(goal, 'ether');
            
            await contract.methods.createCampaign(
                title,
                description,
                goalInWei,
                duration
            ).send({ from: accounts[0] });
            
            alert("Campaign created successfully!");
            document.getElementById('campaign-form').reset();
            loadCampaigns();
        } catch (error) {
            console.error("Error creating campaign:", error);
            alert("Failed to create campaign. See console for details.");
        }
    }

    async function loadCampaigns() {
        if (!contract) return;
        
        const campaignsContainer = document.getElementById('campaigns-container');
        campaignsContainer.innerHTML = '<p>Loading campaigns...</p>';
        
        try {
            const count = await contract.methods.campaignCount().call();
            
            if (count == 0) {
                campaignsContainer.innerHTML = '<p>No campaigns found.</p>';
                return;
            }
            
            campaignsContainer.innerHTML = '';
            
            for (let i = 1; i <= count; i++) {
                const campaign = await contract.methods.getCampaignDetails(i).call();
                
                if (campaign.isCompleted) continue;
                
                const deadlineDate = new Date(campaign.deadline * 1000);
                const progress = (campaign.totalFunds / campaign.goal) * 100;
                const goalEth = web3.utils.fromWei(campaign.goal, 'ether');
                const raisedEth = web3.utils.fromWei(campaign.totalFunds, 'ether');
                
                const campaignElement = document.createElement('div');
                campaignElement.className = 'campaign';
                campaignElement.innerHTML = `
                    <h3>${campaign.title}</h3>
                    <p>${campaign.description}</p>
                    <div class="progress-bar">
                        <div class="progress" style="width: ${Math.min(progress, 100)}%"></div>
                    </div>
                    <div class="campaign-details">
                        <span>Raised: ${raisedEth} ETH / ${goalEth} ETH</span>
                        <span>Ends: ${deadlineDate.toLocaleDateString()}</span>
                    </div>
                    <button class="contribute-btn" data-id="${i}">Contribute</button>
                `;
                
                campaignsContainer.appendChild(campaignElement);
            }
            
            // Add event listeners to contribute buttons
            document.querySelectorAll('.contribute-btn').forEach(button => {
                button.addEventListener('click', (e) => {
                    currentCampaignId = e.target.getAttribute('data-id');
                    openContributeModal(currentCampaignId);
                });
            });
        } catch (error) {
            console.error("Error loading campaigns:", error);
            campaignsContainer.innerHTML = '<p>Error loading campaigns. See console for details.</p>';
        }
    }

    async function openContributeModal(campaignId) {
        if (!contract) return;
        
        try {
            const campaign = await contract.methods.getCampaignDetails(campaignId).call();
            const goalEth = web3.utils.fromWei(campaign.goal, 'ether');
            const raisedEth = web3.utils.fromWei(campaign.totalFunds, 'ether');
            const deadlineDate = new Date(campaign.deadline * 1000);
            
            document.getElementById('modal-title').textContent = `Contribute to ${campaign.title}`;
            document.getElementById('modal-campaign-info').innerHTML = `
                <p>${campaign.description}</p>
                <p><strong>Goal:</strong> ${goalEth} ETH</p>
                <p><strong>Raised:</strong> ${raisedEth} ETH</p>
                <p><strong>Deadline:</strong> ${deadlineDate.toLocaleDateString()}</p>
            `;
            
            document.getElementById('modal').style.display = 'block';
        } catch (error) {
            console.error("Error opening contribute modal:", error);
        }
    }

    async function contributeToCampaign() {
        if (!contract || !currentCampaignId) return;
        
        const amount = document.getElementById('contribution-amount').value;
        
        if (!amount || parseFloat(amount) <= 0) {
            alert("Please enter a valid contribution amount.");
            return;
        }
        
        try {
            const amountInWei = web3.utils.toWei(amount, 'ether');
            
            await contract.methods.contribute(currentCampaignId)
                .send({ 
                    from: accounts[0],
                    value: amountInWei
                });
            
            alert("Contribution successful!");
            document.getElementById('modal').style.display = 'none';
            document.getElementById('contribution-amount').value = '';
            loadCampaigns();
        } catch (error) {
            console.error("Error contributing to campaign:", error);
            alert("Failed to contribute. See console for details.");
        }
    }
});